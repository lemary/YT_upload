import unittest
from unittest import result
from function import get_config, get_table
from function import make_chanel
from simple_youtube_api.Channel import Channel
from simple_youtube_api.LocalVideo import LocalVideo

def search_test(youtube_ids, youtube):
    request = youtube.videos().list(
        part="snippet",
        id=youtube_ids
    )
    response = request.execute()
    return response

class TestGetConfig(unittest.TestCase):
    def test_list_int(self):
        """
        Test that it can sum a list of integers
        """
        result = get_config("tests\\test_config.json")

        true_value = {
            "test1" : [1,2,3],
            "test2" : "test_test"
        }
        self.assertEqual(result, true_value)

class TestUpload(unittest.TestCase):
    def test_upload(self):
        
        channel = make_chanel()
        video =  LocalVideo(file_path = "tests\\test.mp4")
        
        test_names = {
            "title":"test_title",
            "description":"test_description"
        }

        video.set_title(test_names["title"])
        video.set_description(test_names["description"])
        video.set_privacy_status("private")
        video = channel.upload_video(video)
        
        result = search_test([video.id], channel.channel)

        for i in test_names:
            with self.subTest(i = i):
                self.assertEqual(result['items'][0]["snippet"][i], test_names[i])
